--  
--  $Id: q32.sql,v 1.2 2006/08/16 07:58:12 source Exp $
--  
--  This file is part of the OpenLink Software Virtuoso Open-Source (VOS)
--  project.
--  
--  Copyright (C) 1998-2006 OpenLink Software
--  
--  This project is free software; you can redistribute it and/or modify it
--  under the terms of the GNU General Public License as published by the
--  Free Software Foundation; only version 2 of the License, dated June 1991.
--  
--  This program is distributed in the hope that it will be useful, but
--  WITHOUT ANY WARRANTY; without even the implied warranty of
--  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
--  General Public License for more details.
--  
--  You should have received a copy of the GNU General Public License along
--  with this program; if not, write to the Free Software Foundation, Inc.,
--  51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
--  
--  
set autocommit on;
load QS22.sql;
load QS21.sql;
load QS20.sql;
load QS18o.sql;
load QS17.sql;
load QS15.sql;
load QS14.sql;
load QS13.sql;
load QS12.sql;
load QS11.sql;
load QS10.sql;
load QS9.sql;
load QS8.sql;
load QS7.sql;
load QS6.sql;
load QS5.sql;
load QS4.sql;
load QS3.sql;
load QS2.sql;
load QS1.sql;

