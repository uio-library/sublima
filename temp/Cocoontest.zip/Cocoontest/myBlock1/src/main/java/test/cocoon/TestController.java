package test.cocoon;

import org.apache.cocoon.components.flow.apples.AppleRequest;
import org.apache.cocoon.components.flow.apples.AppleResponse;
import org.apache.cocoon.components.flow.apples.StatelessAppleController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author: mha
 * Date: 31.mar.2008
 */
public class TestController implements StatelessAppleController {

    @SuppressWarnings("unchecked")
    public void process(AppleRequest req, AppleResponse res) throws Exception {

        String testResults = "<test>special norwegian characters � � �</test>";
        //testResults = new String(testResults.getBytes(), "UTF-8");
        Map<String, Object> bizData = new HashMap<String, Object>();
        bizData.put("testresults", testResults);
        res.sendPage("xml/test", bizData);

    }
}

